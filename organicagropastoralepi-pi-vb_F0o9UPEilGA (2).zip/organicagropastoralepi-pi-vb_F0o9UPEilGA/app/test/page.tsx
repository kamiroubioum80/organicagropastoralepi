export default function TestPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-amber-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-xl shadow-lg p-8">
        <h1 className="text-3xl font-bold text-green-700 mb-4">
          ORGANIC AGRO-PASTORAL PI (OAPPi)
        </h1>
        <p className="text-gray-700 mb-6">
          Application fonctionnelle - Test réussi
        </p>
        <div className="space-y-4">
          <div className="p-4 bg-green-50 rounded-lg">
            <p className="font-semibold text-green-800">✅ Application chargée</p>
            <p className="text-sm text-green-600">Next.js fonctionne correctement</p>
          </div>
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="font-semibold text-blue-800">📧 Contact</p>
            <p className="text-sm text-blue-600">kamiroubioum98@gmail.com</p>
          </div>
          <div className="p-4 bg-amber-50 rounded-lg">
            <p className="font-semibold text-amber-800">🔗 URL</p>
            <p className="text-sm text-amber-600">https://organicagropasto1207.pinet.com</p>
          </div>
        </div>
        <div className="mt-6">
          <a href="/" className="text-green-600 hover:underline">
            Retour à la page principale
          </a>
        </div>
      </div>
    </div>
  )
}
