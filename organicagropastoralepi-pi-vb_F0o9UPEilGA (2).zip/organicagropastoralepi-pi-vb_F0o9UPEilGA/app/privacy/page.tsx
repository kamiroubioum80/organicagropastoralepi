export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Politique de Confidentialité</h1>
        <p className="text-muted-foreground mb-6">Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}</p>
        
        <div className="space-y-6 text-foreground">
          <section>
            <h2 className="text-2xl font-semibold mb-4">1. Introduction</h2>
            <p>
              OrganicAgropastoralepi.pi (« OAPPi », « nous », « notre ») s'engage à protéger la confidentialité 
              de ses utilisateurs. Cette politique de confidentialité explique comment nous collectons, utilisons, 
              partageons et protégeons vos informations personnelles lorsque vous utilisez notre application 
              intégrée à l'écosystème Pi Network.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">2. Informations que nous collectons</h2>
            <h3 className="text-xl font-semibold mb-2">2.1 Informations d'authentification Pi Network</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>Identifiant utilisateur Pi Network (Pi UID)</li>
              <li>Nom d'utilisateur Pi Network</li>
              <li>Adresse de portefeuille Pi</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">2.2 Informations de transaction</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>Historique des paiements en Pi</li>
              <li>Transactions de tokens OAPPi</li>
              <li>Achats de produits biologiques</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">2.3 Informations d'utilisation</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>Messages du chatbot</li>
              <li>Interactions avec la marketplace</li>
              <li>Données d'analyse d'utilisation de l'application</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">3. Comment nous utilisons vos informations</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Fournir et améliorer nos services de marketplace biologique</li>
              <li>Traiter vos transactions en Pi Network</li>
              <li>Gérer votre compte et vos préférences</li>
              <li>Connecter les producteurs locaux aux consommateurs</li>
              <li>Assurer la sécurité et prévenir la fraude</li>
              <li>Communiquer avec vous concernant votre compte et nos services</li>
              <li>Analyser l'utilisation pour améliorer l'expérience utilisateur</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">4. Partage des informations</h2>
            <p className="mb-4">Nous ne vendons jamais vos données personnelles. Nous pouvons partager vos informations uniquement dans les cas suivants :</p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Avec Pi Network :</strong> Pour l'authentification et le traitement des paiements</li>
              <li><strong>Avec les producteurs :</strong> Informations de commande nécessaires pour la livraison</li>
              <li><strong>Conformité légale :</strong> Si requis par la loi ou pour protéger nos droits</li>
              <li><strong>Prestataires de services :</strong> Partenaires de confiance qui nous aident à exploiter notre application</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">5. Sécurité des données</h2>
            <p>
              Nous mettons en œuvre des mesures de sécurité techniques et organisationnelles appropriées pour 
              protéger vos informations personnelles contre l'accès non autorisé, la modification, la divulgation 
              ou la destruction. Cependant, aucune méthode de transmission sur Internet ou de stockage électronique 
              n'est sécurisée à 100%.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">6. Conservation des données</h2>
            <p>
              Nous conservons vos informations personnelles aussi longtemps que nécessaire pour fournir nos services 
              et respecter nos obligations légales. Vous pouvez demander la suppression de votre compte à tout moment 
              en nous contactant.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">7. Vos droits</h2>
            <p className="mb-4">Vous avez le droit de :</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Accéder à vos informations personnelles</li>
              <li>Corriger des informations inexactes</li>
              <li>Demander la suppression de vos données</li>
              <li>Retirer votre consentement au traitement de vos données</li>
              <li>Exporter vos données dans un format structuré</li>
              <li>Vous opposer au traitement de vos données personnelles</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">8. Cookies et technologies similaires</h2>
            <p>
              Nous utilisons des cookies et technologies similaires pour améliorer votre expérience, analyser 
              l'utilisation de l'application et personnaliser le contenu. Vous pouvez gérer vos préférences de 
              cookies via les paramètres de votre navigateur.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">9. Modifications de cette politique</h2>
            <p>
              Nous pouvons mettre à jour cette politique de confidentialité de temps en temps. Nous vous informerons 
              de tout changement important en publiant la nouvelle politique sur cette page et en mettant à jour la 
              date de "Dernière mise à jour".
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">10. Contact</h2>
            <p>Pour toute question concernant cette politique de confidentialité, contactez-nous :</p>
            <ul className="list-none pl-0 mt-4 space-y-2">
              <li><strong>Email :</strong> kamiroubioum98@gmail.com</li>
              <li><strong>Application :</strong> OrganicAgropastoralepi.pi</li>
              <li><strong>URL :</strong> https://organicagropasto1207.pinet.com</li>
            </ul>
          </section>

          <section className="mt-8 p-6 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">
              En utilisant OrganicAgropastoralepi.pi, vous acceptez cette politique de confidentialité. 
              Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser notre application.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
