"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Send, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-amber-50 p-4">
      <div className="max-w-4xl mx-auto py-8">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-3">Nous Contacter</h1>
          <p className="text-muted-foreground text-lg">
            L'équipe OAPPi est à votre écoute pour toute question ou suggestion
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle>Informations de Contact</CardTitle>
              <CardDescription>Contactez-nous directement via ces canaux</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground mb-1">Email</p>
                  <a
                    href="mailto:kamiroubioum98@gmail.com"
                    className="text-primary hover:underline"
                  >
                    kamiroubioum98@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground mb-1">Téléphone / WhatsApp</p>
                  <p className="text-muted-foreground">Disponible sur demande</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground mb-1">Localisation</p>
                  <p className="text-muted-foreground">Afrique de l'Ouest</p>
                  <p className="text-muted-foreground text-sm">Service disponible dans toute la région</p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <p className="text-sm font-medium text-foreground mb-2">Liens Utiles</p>
                <div className="space-y-2">
                  <Link href="/privacy" className="flex items-center gap-2 text-sm text-primary hover:underline">
                    Politique de Confidentialité
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                  <Link href="/terms" className="flex items-center gap-2 text-sm text-primary hover:underline">
                    Conditions d'Utilisation
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Form */}
          <Card>
            <CardHeader>
              <CardTitle>Envoyez-nous un Message</CardTitle>
              <CardDescription>Nous vous répondrons dans les plus brefs délais</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="text-sm font-medium text-foreground block mb-2">
                    Nom Complet
                  </label>
                  <Input id="name" placeholder="Votre nom" />
                </div>

                <div>
                  <label htmlFor="email" className="text-sm font-medium text-foreground block mb-2">
                    Email
                  </label>
                  <Input id="email" type="email" placeholder="votre@email.com" />
                </div>

                <div>
                  <label htmlFor="subject" className="text-sm font-medium text-foreground block mb-2">
                    Sujet
                  </label>
                  <Input id="subject" placeholder="Objet de votre message" />
                </div>

                <div>
                  <label htmlFor="message" className="text-sm font-medium text-foreground block mb-2">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Décrivez votre demande ou suggestion..."
                    rows={5}
                  />
                </div>

                <Button className="w-full" size="lg">
                  <Send className="w-4 h-4 mr-2" />
                  Envoyer le Message
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  En envoyant ce formulaire, vous acceptez notre{" "}
                  <Link href="/privacy" className="text-primary hover:underline">
                    politique de confidentialité
                  </Link>
                </p>
              </form>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>À Propos d'OAPPi</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              Organic Agro-Pastoral Pi (OAPPi) est une application intégrée à l'écosystème Pi Network,
              dédiée à la promotion, la protection et la commercialisation des produits agro-pastoraux
              biologiques en Afrique de l'Ouest.
            </p>
            <div className="flex items-center gap-4">
              <Button asChild variant="outline">
                <Link href="/">Retour à l'Accueil</Link>
              </Button>
              <Button asChild>
                <a href="https://organicagropasto1207.pinet.com">Accéder à la Plateforme</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
