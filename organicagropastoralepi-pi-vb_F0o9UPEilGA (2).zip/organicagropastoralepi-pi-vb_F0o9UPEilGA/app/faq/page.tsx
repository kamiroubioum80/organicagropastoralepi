export default function FAQPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-amber-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Questions Fréquentes (FAQ)</h1>
          <p className="text-muted-foreground">Tout ce que vous devez savoir sur OrganicAgropastoralepi.pi</p>
        </div>

        <div className="space-y-6">
          {/* Section Générale */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-border">
            <h2 className="text-xl font-semibold text-primary mb-4">À propos d'OAPPi</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Qu'est-ce qu'OrganicAgropastoralepi.pi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  OAPPi est une marketplace digitale intégrée à Pi Network qui connecte les producteurs de produits agro-pastoraux biologiques aux consommateurs. L'application facilite les échanges commerciaux avec paiement en Pi.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Pourquoi utiliser OAPPi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  • Accès direct aux producteurs locaux<br />
                  • Produits 100% biologiques certifiés<br />
                  • Paiements sécurisés en Pi Network<br />
                  • Soutien à l'agriculture durable<br />
                  • Commerce équitable garanti
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Qui peut utiliser OAPPi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Tous les utilisateurs de Pi Network peuvent utiliser OAPPi : producteurs biologiques, consommateurs, revendeurs, et partenaires logistiques.
                </p>
              </div>
            </div>
          </div>

          {/* Section Authentification */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-border">
            <h2 className="text-xl font-semibold text-primary mb-4">Authentification et Compte</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Comment créer un compte ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Aucune inscription séparée nécessaire. Connectez-vous simplement avec votre compte Pi Network existant. L'authentification est sécurisée et gérée par Pi Network.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Ai-je besoin d'un compte Pi Network ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Oui, un compte Pi Network actif est obligatoire pour utiliser OAPPi. Téléchargez l'application Pi Network si vous n'en avez pas encore.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Mes données sont-elles sécurisées ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Oui, nous utilisons l'authentification sécurisée de Pi Network et respectons strictement notre politique de confidentialité. Vos données personnelles ne sont jamais partagées sans votre consentement.
                </p>
              </div>
            </div>
          </div>

          {/* Section Paiements */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-border">
            <h2 className="text-xl font-semibold text-primary mb-4">Paiements et Transactions</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Comment payer sur OAPPi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Tous les paiements se font en Pi Network. Sélectionnez vos produits, validez votre panier, et approuvez le paiement via l'interface Pi.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Le mode Test Net, c'est quoi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Le Test Net est un environnement de test où vous pouvez essayer les paiements sans utiliser de vrais Pi. C'est idéal pour vous familiariser avec le système avant de faire de vraies transactions.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Mes paiements sont-ils sécurisés ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Oui, tous les paiements utilisent le système sécurisé de Pi Network avec validation en deux étapes. Vous gardez le contrôle total de vos transactions.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Puis-je obtenir un remboursement ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Les remboursements sont possibles selon nos conditions d'utilisation. Contactez le service client dans les 48h suivant l'achat pour toute réclamation.
                </p>
              </div>
            </div>
          </div>

          {/* Section Marketplace */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-border">
            <h2 className="text-xl font-semibold text-primary mb-4">Marketplace et Produits</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Quels produits sont disponibles ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Produits agricoles biologiques (légumes, fruits, céréales), produits d'élevage (viandes, œufs, lait), produits transformés (miel, fromage, huiles), et services agricoles.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Comment devenir producteur sur OAPPi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Contactez-nous via la page Contact avec votre certification bio et description de votre production. Notre équipe vérifiera votre éligibilité et vous accompagnera dans l'inscription.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Les produits sont-ils certifiés bio ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Oui, tous les producteurs doivent présenter une certification bio valide. Nous vérifions chaque certification avant d'accepter un producteur sur la plateforme.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Comment suivre ma commande ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Après achat, vous recevez un numéro de suivi. Consultez l'onglet "Mes Commandes" dans votre wallet pour suivre l'état de livraison en temps réel.
                </p>
              </div>
            </div>
          </div>

          {/* Section Tokens et Récompenses */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-border">
            <h2 className="text-xl font-semibold text-primary mb-4">Tokens OAPPi et Récompenses</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Qu'est-ce que les tokens OAPPi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Les tokens OAPPi sont des points de récompense que vous gagnez en utilisant la plateforme. Ils peuvent être échangés contre des réductions ou des produits gratuits.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Comment gagner des tokens ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  • Achats sur la marketplace<br />
                  • Parrainage de nouveaux utilisateurs<br />
                  • Participation aux événements communautaires<br />
                  • Évaluations de produits<br />
                  • Fidélité mensuelle
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Puis-je convertir mes tokens en Pi ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Actuellement, les tokens OAPPi sont utilisables uniquement sur la plateforme. Une fonctionnalité de conversion pourrait être ajoutée dans une future mise à jour.
                </p>
              </div>
            </div>
          </div>

          {/* Section Support */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-border">
            <h2 className="text-xl font-semibold text-primary mb-4">Support et Assistance</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Comment contacter le support ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Email : kamiroubioum98@gmail.com<br />
                  Formulaire de contact : <a href="/contact" className="text-primary hover:underline">Page Contact</a><br />
                  Délai de réponse : 24-48 heures
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">L'application est-elle disponible en plusieurs langues ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Actuellement disponible en français. D'autres langues (anglais, portugais) seront ajoutées selon les demandes de la communauté.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Que faire en cas de problème technique ?</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Contactez-nous immédiatement via email avec une description du problème et des captures d'écran si possible. Notre équipe technique vous aidera dans les plus brefs délais.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Links */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">Vous n'avez pas trouvé votre réponse ?</p>
          <div className="flex items-center justify-center gap-4">
            <a href="/contact" className="text-primary hover:underline text-sm font-medium">Contactez-nous</a>
            <span className="text-muted-foreground">•</span>
            <a href="/" className="text-primary hover:underline text-sm font-medium">Retour à l'accueil</a>
          </div>
        </div>
      </div>
    </div>
  )
}
