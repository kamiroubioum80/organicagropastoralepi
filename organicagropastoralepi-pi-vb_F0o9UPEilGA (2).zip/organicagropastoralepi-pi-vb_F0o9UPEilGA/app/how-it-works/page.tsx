import { Leaf, UserCheck, ShoppingCart, Coins, Package, Truck, CheckCircle } from "lucide-react"

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-amber-50 p-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary mb-4">
            <Leaf className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-3">Comment ça marche ?</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Découvrez comment utiliser OrganicAgropastoralepi.pi en quelques étapes simples
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-8 mb-12">
          {/* Step 1 */}
          <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-primary">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl font-bold text-primary">01</span>
                  <h3 className="text-xl font-semibold text-foreground">Créez votre compte</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-3">
                  Connectez-vous simplement avec votre compte Pi Network existant. Aucune inscription supplémentaire nécessaire. L'authentification est rapide et sécurisée.
                </p>
                <div className="bg-green-50 rounded-lg p-3 text-sm text-foreground">
                  <strong>Astuce :</strong> Assurez-vous d'avoir l'application Pi Network installée sur votre appareil avant de commencer.
                </div>
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-emerald-500">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 text-emerald-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl font-bold text-emerald-600">02</span>
                  <h3 className="text-xl font-semibold text-foreground">Explorez la Marketplace</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-3">
                  Parcourez notre catalogue de produits agro-pastoraux biologiques certifiés. Filtrez par catégorie, prix, ou producteur pour trouver exactement ce dont vous avez besoin.
                </p>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="bg-emerald-50 rounded-lg p-3">
                    <strong className="text-foreground">Produits agricoles</strong>
                    <p className="text-muted-foreground text-xs mt-1">Légumes, fruits, céréales bio</p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg p-3">
                    <strong className="text-foreground">Produits d'élevage</strong>
                    <p className="text-muted-foreground text-xs mt-1">Viandes, œufs, produits laitiers</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-amber-500">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center">
                <Coins className="w-6 h-6 text-amber-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl font-bold text-amber-600">03</span>
                  <h3 className="text-xl font-semibold text-foreground">Payez en Pi Network</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-3">
                  Ajoutez vos produits au panier et validez votre commande. Le paiement se fait en toute sécurité avec vos Pi via le système de paiement intégré de Pi Network.
                </p>
                <div className="bg-amber-50 rounded-lg p-3 text-sm">
                  <strong className="text-foreground">Mode Test Net disponible :</strong>
                  <p className="text-muted-foreground mt-1">Essayez le système de paiement sans risque avant de faire de vraies transactions.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Step 4 */}
          <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-blue-500">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Truck className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl font-bold text-blue-600">04</span>
                  <h3 className="text-xl font-semibold text-foreground">Suivez votre livraison</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-3">
                  Recevez une confirmation immédiate et suivez votre commande en temps réel. Notre service logistique assure une livraison rapide et dans les meilleures conditions.
                </p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Livraison en 24-48h dans les zones couvertes</span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 5 */}
          <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-purple-500">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Package className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl font-bold text-purple-600">05</span>
                  <h3 className="text-xl font-semibold text-foreground">Gagnez des récompenses</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-3">
                  Chaque achat vous rapporte des tokens OAPPi. Accumulez-les pour obtenir des réductions, des produits gratuits, ou participez à des événements exclusifs.
                </p>
                <div className="grid grid-cols-3 gap-2 text-xs text-center">
                  <div className="bg-purple-50 rounded p-2">
                    <div className="font-bold text-purple-600">+10</div>
                    <div className="text-muted-foreground">Par achat</div>
                  </div>
                  <div className="bg-purple-50 rounded p-2">
                    <div className="font-bold text-purple-600">+50</div>
                    <div className="text-muted-foreground">Parrainage</div>
                  </div>
                  <div className="bg-purple-50 rounded p-2">
                    <div className="font-bold text-purple-600">+25</div>
                    <div className="text-muted-foreground">Avis produit</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* For Producers */}
        <div className="bg-gradient-to-r from-primary to-emerald-600 rounded-xl p-8 text-white mb-12">
          <h2 className="text-2xl font-bold mb-4">Vous êtes producteur ?</h2>
          <p className="leading-relaxed mb-6 opacity-90">
            Rejoignez notre réseau de producteurs biologiques certifiés et vendez vos produits directement aux consommateurs. Bénéficiez de notre plateforme, de notre logistique, et d'un accompagnement personnalisé.
          </p>
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Visibilité maximale</h3>
              <p className="text-sm opacity-90">Accédez à des milliers de clients potentiels</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Paiements sécurisés</h3>
              <p className="text-sm opacity-90">Recevez vos paiements en Pi rapidement</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h3 className="font-semibold mb-2">Support logistique</h3>
              <p className="text-sm opacity-90">Nous gérons le transport et la livraison</p>
            </div>
          </div>
          <a href="/contact" className="inline-block bg-white text-primary px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
            Devenir producteur partenaire
          </a>
        </div>

        {/* CTA */}
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-3">Prêt à commencer ?</h2>
          <p className="text-muted-foreground mb-6">Rejoignez la communauté OAPPi et soutenez l'agriculture biologique locale</p>
          <div className="flex items-center justify-center gap-4">
            <a href="/" className="bg-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors">
              Accéder à la plateforme
            </a>
            <a href="/faq" className="border border-border px-6 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
              Voir la FAQ
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
