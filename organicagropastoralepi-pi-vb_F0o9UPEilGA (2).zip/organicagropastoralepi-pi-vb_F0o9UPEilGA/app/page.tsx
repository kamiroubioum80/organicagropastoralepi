import { Leaf, Package, Coins, Users, FileText, Scale, ShoppingCart, Info } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-amber-50">
      <div className="max-w-6xl mx-auto p-4 py-8">
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-green-600 flex items-center justify-center shadow-lg">
              <Leaf className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">ORGANIC AGRO-PASTORAL PI</h1>
              <p className="text-gray-600">OrganicAgropastoralepi.pi</p>
            </div>
          </div>

          <div className="prose max-w-none mb-8">
            <p className="text-lg text-gray-700 leading-relaxed">
              Organic Agro-Pastoral Pi (OAPPi) est une application intégrée à l'écosystème Pi Network, 
              dédiée à la promotion, la protection et la commercialisation des produits agro-pastoraux biologiques.
            </p>
            <p className="text-gray-700 mt-4">
              Elle connecte les producteurs locaux aux consommateurs grâce à une marketplace digitale simple 
              et sécurisée, avec paiement en Pi Network.
            </p>
          </div>

          <div className="bg-green-50 rounded-xl p-6 mb-8">
            <h2 className="text-xl font-bold text-green-800 mb-3">Fonctionnalités</h2>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                Authentification Pi Network
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                Marketplace de produits biologiques
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                Paiements en Pi (Testnet)
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                Système de tokens et récompenses
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                Gestion des contrats et licences
              </li>
            </ul>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white border-2 border-green-200 rounded-xl p-4 text-center hover:shadow-lg transition-shadow">
              <Package className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-800">Produits Bio</p>
            </div>
            <div className="bg-white border-2 border-green-200 rounded-xl p-4 text-center hover:shadow-lg transition-shadow">
              <Coins className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-800">Tokens OAPPi</p>
            </div>
            <div className="bg-white border-2 border-green-200 rounded-xl p-4 text-center hover:shadow-lg transition-shadow">
              <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-800">Actionnaires</p>
            </div>
            <div className="bg-white border-2 border-green-200 rounded-xl p-4 text-center hover:shadow-lg transition-shadow">
              <FileText className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-800">Contrats</p>
            </div>
          </div>

          <div className="bg-blue-50 rounded-xl p-6">
            <h3 className="text-lg font-bold text-blue-800 mb-3">Contact</h3>
            <p className="text-gray-700">
              <strong>Email:</strong> kamiroubioum98@gmail.com
            </p>
            <p className="text-gray-700 mt-2">
              <strong>URL:</strong> https://organicagropasto1207.pinet.com
            </p>
          </div>
        </div>

          <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-6 mb-6">
            <a href="/how-it-works" className="text-green-600 hover:text-green-700 font-semibold hover:underline">
              Comment ça marche ?
            </a>
            <span className="text-gray-400">•</span>
            <a href="/faq" className="text-green-600 hover:text-green-700 font-semibold hover:underline">
              Questions fréquentes
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <a href="/privacy" className="bg-white rounded-lg p-4 hover:shadow-lg transition-shadow">
              <Scale className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <p className="font-semibold text-gray-800">Politique de Confidentialité</p>
            </a>
            <a href="/terms" className="bg-white rounded-lg p-4 hover:shadow-lg transition-shadow">
              <FileText className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <p className="font-semibold text-gray-800">Conditions d'Utilisation</p>
            </a>
            <a href="/contact" className="bg-white rounded-lg p-4 hover:shadow-lg transition-shadow">
              <Info className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <p className="font-semibold text-gray-800">Nous Contacter</p>
            </a>
          </div>

          <div className="text-sm text-gray-600">
            <p className="font-semibold">Organic Agro-Pastoralpi.pi (OAPPi)</p>
            <p className="text-xs mt-1">
              Promotion • Transport • Commercialisation • Financement des producteurs bio
            </p>
            <p className="text-xs mt-1">
              Propulsé par Pi Network • Commerce Équitable • Afrique de l'Ouest
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
